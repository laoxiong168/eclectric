package com.teclic.handle;

import java.io.IOException;

import com.elec.Broadcast;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
        Broadcast broadcast= new Broadcast(9999);

        try {
            for (int i = 0; i < 100; i++) {
                broadcast.send("send data -- "+i,9999);
                System.out.println("第--"+i+"--次发送数据");
                Thread.sleep(2000);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
